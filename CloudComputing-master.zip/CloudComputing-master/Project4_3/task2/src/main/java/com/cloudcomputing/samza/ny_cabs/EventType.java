package com.cloudcomputing.samza.ny_cabs;

/**
 * Created by qichenzhang on 5/3/17.
 */
public class EventType {
    public static final String LEAVING_BLOCK = "LEAVING_BLOCK";
    public static final String ENTERING_BLOCK = "ENTERING_BLOCK";
    public static final String RIDE_REQUEST = "RIDE_REQUEST";
    public static final String RIDE_COMPLETE = "RIDE_COMPLETE";
}
