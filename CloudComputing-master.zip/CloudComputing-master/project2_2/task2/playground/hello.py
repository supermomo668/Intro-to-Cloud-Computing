import sys
sys.stdout.write('hello\n')
