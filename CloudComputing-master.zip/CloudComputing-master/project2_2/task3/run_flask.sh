#!/bin/bash

# For task 3 you will want to change
# playground.py to playground-ecs.py

# for Python 3
#export FLASK_APP=playground.py
#python -m flask run

# for Python 2
python playground-ecs.py
