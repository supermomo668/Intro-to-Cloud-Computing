# Upload to BI
scp -i ~/Documents/15619/aws/15619_CC.pem ./ProfileServlet.java ./HomepageServlet.java ./FollowerServlet.java TimelineServlet.java qichenz@ec2-52-91-99-110.compute-1.amazonaws.com:Project3_3/src/main/java/cc/cmu/edu/minisite/
