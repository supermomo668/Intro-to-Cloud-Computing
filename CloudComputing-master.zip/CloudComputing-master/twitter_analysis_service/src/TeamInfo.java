

public class TeamInfo {
	public static final String TEAM_ID = "15619isAwesome";
	public static final String AWS_ACCOUNT_ID = "756424906584";
}
