# CloudComputing
Projects of CMU course 15213.

Contains code of my individual projects and term proj ect. I found that it is tedious to organize my legacy code, so I just copy-paste them together. :)
